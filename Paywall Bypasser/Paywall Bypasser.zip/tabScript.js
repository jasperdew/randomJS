window.localStorage.clear();
